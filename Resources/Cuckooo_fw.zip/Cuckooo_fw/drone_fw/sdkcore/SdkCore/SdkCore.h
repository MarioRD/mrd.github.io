#import <Foundation/Foundation.h>

//! Project version number for SdkCore.
FOUNDATION_EXPORT double SdkCoreVersionNumber;

//! Project version string for SdkCore.
FOUNDATION_EXPORT const unsigned char SdkCoreVersionString[];

// Import components
#include "Arsdk.h"

// Mavlink
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Waddress-of-packed-member"
#pragma clang diagnostic pop
