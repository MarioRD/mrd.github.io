/* We need to compile an empty cpp file to force build to include
 * a C++ STL library into the application */
